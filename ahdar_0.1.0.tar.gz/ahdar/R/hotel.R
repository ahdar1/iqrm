#' Fictitious data.
#' Hotel satisfaction survey.
#'
#' @format A data frame with 600 rows and three columns.
#' \describe{
#'  \item{Y1}{Do you like the hotel?, 1 = Yes, 2 = No}
#'  \item{Y2}{Are you satisfied with the hotel?, 1 = Yes, 2 = No }
#'  \item{Y3}{Will you visit the hotel again in the future?, 1 = Yes, 2 = No}
#'  \item{Y4}{Will you recommend the hotel to your friends? , 1 = Yes, 2 = No}
#'  }
#'

"hotel"

