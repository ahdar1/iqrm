#' Electric Guitar.
#'
#' Fictitious Survey data.
#'
#' @format A data frame with 30 rows and 2 two columns.
#' \describe{
#'  \item{Own}{Ownership 1 = yes, 0 = No}
#'  \item{Years}{number of years playing guitar}
#'  }
"guitar"

