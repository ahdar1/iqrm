#' Anscombe's Quartet.
#'
#'Reference: Anscombe, Francis J. (1973). Graphs in statistical analysis. The American Statistician, 27, 17–21. doi:10.2307/2682899.
#' @format A data frame with 11 rows and 8 variables:
#'
"anscombe"

