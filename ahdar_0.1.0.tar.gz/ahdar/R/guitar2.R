#' Electric Guitar ver2.
#'
#' Fictitious Survey data.
#'
#' @format A data frame with 30 rows and 3 two columns.
#' \describe{
#'  \item{Own}{Ownership 1 = yes, 0 = No}
#'  \item{Years}{number of years playing guitar}
#'  \item{Rock}{I like Rock music, 1 = strongly disagree, 7 = strongly agree}
#'  }
"guitar2"

