#' A fake sales data.
#'
#' @format A data frame with 31 rows and 2 variables:
#' \code{Sales} and \code{Adv}.
"sales"

