#' Sustainable food consumption.
#' This is a survey data. All variables are measured
#' using a 7-point Likert-scale ranging from 1= strongly disagree
#' to 7 = strongly agree.
#'
#' @format A data frame with 309 rows and 7 Likert variables:
#' \code{SFC1}, \code{SFC2}, \code{SFC3}, \code{SFC4},
#' \code{EA1}, \code{EA2}, \code{EA3}.
"sfc"

