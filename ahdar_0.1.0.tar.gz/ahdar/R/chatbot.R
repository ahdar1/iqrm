#' Fictitious data.
#' 30 random consumers participated in a chatbot session.
#'
#' @format A data frame with 30 rows and 3 two columns.
#' \describe{
#'  \item{Like}{Do you like the chatbot? 1 = yes, 0 = No}
#'  \item{Age}{Age of participants in years}
#'  \item{Duration}{Duration of a chatbot session in minutes}
#'  }
"chatbot"

