#' Spending.
#'
#' @format A data frame with 100 rows and 2 variables:
#'
"spending"

