#' A fictitious experimental data.
#'
#' To study the effect framing and gender on pro-environmental behaviour.
#'
#' @format A data frame with 140 rows and 4 variables:
#' \describe{
#'  \item{Framing}{0 = Father-nature, 1 = Mother-nature}
#'  \item{Gender}{0 = Male, 1 = Female}
#'  \item{PEB}{Score on Pro-environmental Behaviour}
#'  \item{Age}{Age as a continous variable}
#'  }
"nature"
