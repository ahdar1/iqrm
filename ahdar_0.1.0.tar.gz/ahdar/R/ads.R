#' Ads.
#'
#' Experimental data.
#'
#' @format Crosstabulation with 2 rows and 3 three columns.
#' \describe{
#'  \item{Condition}{Types of ad}
#'  \item{Yes}{number of yes}
#'  \item{No}{number of no}
#'  \item{Total}{sums or row}
#'  }
"ads"

