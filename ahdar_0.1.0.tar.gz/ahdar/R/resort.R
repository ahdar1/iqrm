#' Fictitious data.
#' 500 tourists participated in a satisfaction survey.
#'
#' @format A data frame with 500 rows and three columns.
#' \describe{
#'  \item{Y1}{Do you like the place?, 1 = Yes, 2 = No}
#'  \item{Y2}{Are you satisfied with the place?, 1 = Yes, 2 = No }
#'  \item{Y3}{Will you visit the place again in the future?, 1 = Yes, 2 = No}
#'  \item{Y4}{Will you recommend the place to your friends? , 1 = Yes, 2 = No}
#'  }
#'

"resort"

