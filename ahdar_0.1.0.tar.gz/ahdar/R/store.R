#' Store.
#'
#' @format A data frame with 60 rows and 7 variables:
#' \describe{
#'  \item{obs}{Observation number}
#'  \item{brand}{Brand evaluation 1 = Very Bad, 5 = Very good}
#'  \item{gender}{0 = male, 1 = female}
#'  \item{satemp}{composite score of satisfaction toward service employee}
#'  \item{satstore}{satisfaction toward a store measured with a 7-point rating scale ranging from 1= very dissatisfied to 7 = very satisfied}
#'  \item{age}{Age of respondents as a continuous variable}
#'  \item{wt}{subjective waiting time in minutes}
#'  }
"store"


