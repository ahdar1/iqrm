#' fa_qual data.
#'
#' @format A data frame with 243 rows and 5 variables:
#' \code{V1}, \code{V2}, \code{V3}, \code{V4} and \code{V5}.
"fa_qual"
