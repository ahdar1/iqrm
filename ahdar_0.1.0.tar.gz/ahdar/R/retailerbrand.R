#' Retailer Brand.
#' This is a survey data. All variables are measured
#' using a 7-point Likert-scale ranging from 1= strongly disagree
#' to 7 = strongly agree.
#'
#' @format A data frame with 500 rows and 27 columns.
"retailerbrand"

