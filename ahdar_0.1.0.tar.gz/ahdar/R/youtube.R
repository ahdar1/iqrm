#' Data on an Youtube influencer.
#'
#' @format A data frame with 10 rows and 3 variables:
#' \describe{
#'  \item{Group}{Cluster}
#'  \item{Like}{The average likes in thousands that an influencer received on a new post on YouTube}
#'  \item{Subscribes}{the number of subscribers in millions}
#'  }
"youtube"


