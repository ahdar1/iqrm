#' Fictitious data.
#' Satisfaction.
#'
#' @format A data frame with 200 rows and two columns.
#' \describe{
#'  \item{Loyal}{Loyal, 1 = Yes, 0 = No}
#'  \item{Sat}{Average score of satisfaction}
#'  }
#'

"satisfaction"

