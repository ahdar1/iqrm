#' Small data set for PCA.
#'
#' @format A data frame with 5 rows and 2 variables.
"pca_mini_data"

