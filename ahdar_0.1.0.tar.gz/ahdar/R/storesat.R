#' Store Satisfaction.
#'
#' @format A data frame with 60 rows and 16 variables:
#'
"storesat"

