#' Magic Lady.
#'
#' Tasting tea experiment.
#'
#' @format A data frame with 30 rows and 1 variable:
#' \describe{
#'  \item{Guess}{Number of guess}
#'  }
#'
"magiclady"

