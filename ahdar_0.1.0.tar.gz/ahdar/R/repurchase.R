#' Repurchase.
#'
#' @format A data frame with 9 rows and 3 variables:
#' \code{age}, \code{repurchase}, \code{male}.
#' \describe{
#'  \item{age}{Age category; 1 = young, 2 = middle, 3 = old}
#'  \item{repurchase}{I want to repurchase product A if it is available again in this store,
#'  1 = strongly disagree, 7 = strongly agree}
#'  \item{male}{1 = male, 0 = female}
#' }
"repurchase"
