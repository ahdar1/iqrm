#' Empathyv2.
#'
#' @format A data frame with 206 rows and 25 variables:
#'
"empathyv2"

