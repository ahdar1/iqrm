#' Empathy.
#'
#' @format A data frame with 206 rows and 22 variables:
#'
"empathy"

