#' A fake data used PCA chapter.
#'
#' @format A data frame with 200 rows and 5 variables:
#' \code{V1}, \code{V2}, \code{V3}, \code{V4} and \code{V5}.
"fake_data_for_pca"
