#' Quantile.
#'
#' A fake data.
#'
#' @format A single variable data with 8 rows:
#' \code{value}.
"quantile"
