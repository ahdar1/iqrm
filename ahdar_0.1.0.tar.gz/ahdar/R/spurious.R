#' Spurious.
#'
#' @format A data frame with 300 rows and 4 variables:
#'
"spurious"

